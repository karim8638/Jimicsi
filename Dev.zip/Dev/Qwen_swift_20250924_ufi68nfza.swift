// This file contains both iOS and Android implementations
// For iOS: Use Swift code below
// For Android: Use Java code in comments

#if canImport(UIKit)
// MARK: - iOS Implementation
import UIKit

// MARK: - Habit Model
struct Habit: Codable {
    var id: UUID
    var name: String
    var description: String
    var completedDates: [Date]
    var createdAt: Date
    var streak: Int
    var frequency: String
    
    init(name: String, description: String = "") {
        self.id = UUID()
        self.name = name
        self.description = description
        self.completedDates = []
        self.createdAt = Date()
        self.streak = 0
        self.frequency = "daily"
    }
    
    mutating func completeToday() {
        let today = Calendar.current.startOfDay(for: Date())
        if !completedDates.contains(where: { Calendar.current.isDate($0, inSameDayAs: today) }) {
            completedDates.append(Date())
            updateStreak()
        }
    }
    
    mutating func updateStreak() {
        var currentStreak = 0
        let today = Calendar.current.startOfDay(for: Date())
        
        // Sort dates in descending order
        let sortedDates = completedDates.sorted(by: >)
        
        for date in sortedDates {
            let startOfDay = Calendar.current.startOfDay(for: date)
            let expectedDate = Calendar.current.startOfDay(for: today.addingTimeInterval(-Double(currentStreak) * 24 * 3600))
            
            if Calendar.current.isDate(startOfDay, inSameDayAs: expectedDate) {
                currentStreak += 1
            } else if Calendar.current.startOfDay(for: date) < expectedDate {
                break // Gap found, streak broken
            }
        }
        self.streak = currentStreak
    }
}

// MARK: - Data Manager
class HabitDataManager {
    static let shared = HabitDataManager()
    private let userDefaults = UserDefaults.standard
    private let habitsKey = "SavedHabits"
    
    private init() {}
    
    func saveHabits(_ habits: [Habit]) {
        if let encoded = try? JSONEncoder().encode(habits) {
            userDefaults.set(encoded, forKey: habitsKey)
        }
    }
    
    func loadHabits() -> [Habit] {
        guard let data = userDefaults.data(forKey: habitsKey),
              let habits = try? JSONDecoder().decode([Habit].self, from: data) else {
            return []
        }
        return habits
    }
    
    func addHabit(_ habit: Habit) {
        var habits = loadHabits()
        habits.append(habit)
        saveHabits(habits)
    }
    
    func updateHabit(_ updatedHabit: Habit) {
        var habits = loadHabits()
        if let index = habits.firstIndex(where: { $0.id == updatedHabit.id }) {
            habits[index] = updatedHabit
            saveHabits(habits)
        }
    }
    
    func deleteHabit(_ habitId: UUID) {
        var habits = loadHabits()
        habits.removeAll { $0.id == habitId }
        saveHabits(habits)
    }
}

// MARK: - Habit Cell
class HabitTableViewCell: UITableViewCell {
    private let nameLabel = UILabel()
    private let streakLabel = UILabel()
    private let completeButton = UIButton(type: .system)
    private let deleteButton = UIButton(type: .system)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        // Name Label
        nameLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameLabel)
        
        // Streak Label
        streakLabel.font = UIFont.systemFont(ofSize: 14)
        streakLabel.textColor = UIColor.systemGray
        streakLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(streakLabel)
        
        // Complete Button
        completeButton.setTitle("✓", for: .normal)
        completeButton.backgroundColor = UIColor.systemGreen
        completeButton.setTitleColor(.white, for: .normal)
        completeButton.layer.cornerRadius = 12
        completeButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        completeButton.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(completeButton)
        
        // Delete Button
        deleteButton.setTitle("✕", for: .normal)
        deleteButton.backgroundColor = UIColor.systemRed
        deleteButton.setTitleColor(.white, for: .normal)
        deleteButton.layer.cornerRadius = 12
        deleteButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        deleteButton.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(deleteButton)
        
        // Constraints
        NSLayoutConstraint.activate([
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: streakLabel.leadingAnchor, constant: -8),
            
            streakLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            streakLabel.trailingAnchor.constraint(equalTo: completeButton.leadingAnchor, constant: -8),
            
            completeButton.widthAnchor.constraint(equalToConstant: 24),
            completeButton.heightAnchor.constraint(equalToConstant: 24),
            completeButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            completeButton.trailingAnchor.constraint(equalTo: deleteButton.leadingAnchor, constant: -8),
            
            deleteButton.widthAnchor.constraint(equalToConstant: 24),
            deleteButton.heightAnchor.constraint(equalToConstant: 24),
            deleteButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            deleteButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            contentView.bottomAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 12)
        ])
    }
    
    func configure(with habit: Habit, completeAction: @escaping () -> Void, deleteAction: @escaping () -> Void) {
        nameLabel.text = habit.name
        streakLabel.text = "Streak: \(habit.streak) days"
        completeButton.addTarget(nil, action: #selector(completeAction), for: .touchUpInside)
        deleteButton.addTarget(nil, action: #selector(deleteAction), for: .touchUpInside)
    }
}

// MARK: - Main View Controller
class MainViewController: UIViewController {
    private let tableView = UITableView()
    private let addHabitButton = UIButton(type: .system)
    private var habits: [Habit] = []
    private let dataManager = HabitDataManager.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadHabits()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadHabits()
    }
    
    private func setupUI() {
        title = "Jimicsi"
        view.backgroundColor = UIColor.systemBackground
        
        // Table View
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(HabitTableViewCell.self, forCellReuseIdentifier: "HabitCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        // Add Button
        addHabitButton.setTitle("+", for: .normal)
        addHabitButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        addHabitButton.backgroundColor = UIColor.systemBlue
        addHabitButton.setTitleColor(.white, for: .normal)
        addHabitButton.layer.cornerRadius = 28
        addHabitButton.translatesAutoresizingMaskIntoConstraints = false
        addHabitButton.addTarget(self, action: #selector(addHabitTapped), for: .touchUpInside)
        view.addSubview(addHabitButton)
        
        // Constraints
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: addHabitButton.topAnchor, constant: -16),
            
            addHabitButton.widthAnchor.constraint(equalToConstant: 56),
            addHabitButton.heightAnchor.constraint(equalToConstant: 56),
            addHabitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            addHabitButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24)
        ])
        
        // Navigation bar styling
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always
    }
    
    private func loadHabits() {
        habits = dataManager.loadHabits()
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @objc private func addHabitTapped() {
        let alert = UIAlertController(title: "Add New Habit", message: "Enter habit name", preferredStyle: .alert)
        
        alert.addTextField { textField in
            textField.placeholder = "Habit name"
            textField.autocapitalizationType = .sentences
        }
        
        let addAction = UIAlertAction(title: "Add", style: .default) { [weak self] _ in
            if let habitName = alert.textFields?.first?.text, !habitName.isEmpty {
                let newHabit = Habit(name: habitName)
                self?.dataManager.addHabit(newHabit)
                self?.loadHabits()
            }
        }
        
        alert.addAction(addAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
    
    private func completeHabit(at index: Int) {
        var habit = habits[index]
        habit.completeToday()
        dataManager.updateHabit(habit)
        loadHabits()
    }
    
    private func deleteHabit(at index: Int) {
        let habitToDelete = habits[index]
        dataManager.deleteHabit(habitToDelete.id)
        loadHabits()
    }
}

// MARK: - Table View Data Source & Delegate
extension MainViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return habits.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "HabitCell", for: indexPath) as? HabitTableViewCell else {
            return UITableViewCell()
        }
        
        let habit = habits[indexPath.row]
        cell.configure(
            with: habit,
            completeAction: { [weak self] in
                self?.completeHabit(at: indexPath.row)
            },
            deleteAction: { [weak self] in
                self?.deleteHabit(at: indexPath.row)
            }
        )
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

// MARK: - App Delegate
@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }
    
    // MARK: UISceneSession Lifecycle
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
}

// MARK: - Scene Delegate
class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        window = UIWindow(windowScene: windowScene)
        let mainViewController = MainViewController()
        let navigationController = UINavigationController(rootViewController: mainViewController)
        
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }
}

#else
// MARK: - Android Implementation (Java in comments)
/*
package com.karimtech.jimicsi;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

// Main Activity
public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private HabitAdapter adapter;
    private List<Habit> habits;
    private HabitDatabase database;
    private Button addHabitButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        initDatabase();
        loadHabits();
        setupRecyclerView();
        setupAddButton();
    }
    
    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        addHabitButton = findViewById(R.id.addHabitButton);
    }
    
    private void initDatabase() {
        database = new HabitDatabase(this);
    }
    
    private void loadHabits() {
        habits = database.loadHabits();
        if (adapter != null) {
            adapter.updateHabits(habits);
        }
    }
    
    private void setupRecyclerView() {
        adapter = new HabitAdapter(habits, this::onHabitCompleted, this::onHabitDeleted);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
    
    private void setupAddButton() {
        addHabitButton.setOnClickListener(v -> showAddHabitDialog());
    }
    
    private void showAddHabitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Habit");
        
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint("Habit name");
        builder.setView(input);
        
        builder.setPositiveButton("Add", (dialog, which) -> {
            String habitName = input.getText().toString().trim();
            if (!habitName.isEmpty()) {
                Habit newHabit = new Habit(habitName, "");
                database.addHabit(newHabit);
                loadHabits();
            }
        });
        
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    
    private void onHabitCompleted(Habit habit) {
        habit.completeToday();
        database.updateHabit(habit);
        loadHabits();
    }
    
    private void onHabitDeleted(Habit habit) {
        database.deleteHabit(habit.getId());
        loadHabits();
    }
}

// Habit Model
class Habit {
    private String id;
    private String name;
    private String description;
    private List<String> completedDates;
    private String createdAt;
    private int streak;
    private String frequency;
    
    public Habit(String name, String description) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.description = description;
        this.completedDates = new ArrayList<>();
        this.createdAt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        this.streak = 0;
        this.frequency = "daily";
    }
    
    public void completeToday() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        if (!completedDates.contains(today)) {
            completedDates.add(today);
            updateStreak();
        }
    }
    
    private void updateStreak() {
        // Simple streak calculation
        Calendar cal = Calendar.getInstance();
        int currentStreak = 0;
        
        for (int i = completedDates.size() - 1; i >= 0; i--) {
            String dateStr = completedDates.get(i);
            try {
                Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateStr);
                Calendar dateCal = Calendar.getInstance();
                dateCal.setTime(date);
                
                // Check if this date is consecutive
                if (i == completedDates.size() - 1 || 
                    (cal.get(Calendar.DAY_OF_YEAR) - dateCal.get(Calendar.DAY_OF_YEAR) == 1)) {
                    currentStreak++;
                    cal = dateCal;
                } else {
                    break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.streak = currentStreak;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public List<String> getCompletedDates() { return completedDates; }
    public String getCreatedAt() { return createdAt; }
    public int getStreak() { return streak; }
    public String getFrequency() { return frequency; }
    
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setDescription(String description) { this.description = description; }
    public void setCompletedDates(List<String> completedDates) { this.completedDates = completedDates; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    public void setStreak(int streak) { this.streak = streak; }
    public void setFrequency(String frequency) { this.frequency = frequency; }
}

// Habit Adapter
class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.ViewHolder> {
    private List<Habit> habits;
    private OnHabitCompletedListener onHabitCompletedListener;
    private OnHabitDeletedListener onHabitDeletedListener;
    
    public interface OnHabitCompletedListener {
        void onHabitCompleted(Habit habit);
    }
    
    public interface OnHabitDeletedListener {
        void onHabitDeleted(Habit habit);
    }
    
    public HabitAdapter(List<Habit> habits, 
                       OnHabitCompletedListener onHabitCompletedListener,
                       OnHabitDeletedListener onHabitDeletedListener) {
        this.habits = habits;
        this.onHabitCompletedListener = onHabitCompletedListener;
        this.onHabitDeletedListener = onHabitDeletedListener;
    }
    
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_habit, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Habit habit = habits.get(position);
        holder.bind(habit);
    }
    
    @Override
    public int getItemCount() {
        return habits.size();
    }
    
    public void updateHabits(List<Habit> newHabits) {
        this.habits = newHabits;
        notifyDataSetChanged();
    }
    
    class ViewHolder extends RecyclerView.ViewHolder {
        TextView habitNameText;
        TextView streakText;
        Button completeButton;
        ImageButton deleteButton;
        
        ViewHolder(View itemView) {
            super(itemView);
            habitNameText = itemView.findViewById(R.id.habitNameText);
            streakText = itemView.findViewById(R.id.streakText);
            completeButton = itemView.findViewById(R.id.completeButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
        
        void bind(Habit habit) {
            habitNameText.setText(habit.getName());
            streakText.setText("Streak: " + habit.getStreak() + " days");
            
            completeButton.setOnClickListener(v -> onHabitCompletedListener.onHabitCompleted(habit));
            deleteButton.setOnClickListener(v -> onHabitDeletedListener.onHabitDeleted(habit));
        }
    }
}

// Database Layer
class HabitDatabase {
    private static final String PREFS_NAME = "HabitPrefs";
    private static final String HABITS_KEY = "SavedHabits";
    private SharedPreferences sharedPreferences;
    private Gson gson;
    
    public HabitDatabase(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }
    
    public void saveHabits(List<Habit> habits) {
        String json = gson.toJson(habits);
        sharedPreferences.edit().putString(HABITS_KEY, json).apply();
    }
    
    public List<Habit> loadHabits() {
        String json = sharedPreferences.getString(HABITS_KEY, "");
        if (json.isEmpty()) {
            return new ArrayList<>();
        }
        
        Type listType = new TypeToken<List<Habit>>(){}.getType();
        return gson.fromJson(json, listType);
    }
    
    public void addHabit(Habit habit) {
        List<Habit> habits = loadHabits();
        habits.add(habit);
        saveHabits(habits);
    }
    
    public void updateHabit(Habit updatedHabit) {
        List<Habit> habits = loadHabits();
        for (int i = 0; i < habits.size(); i++) {
            if (habits.get(i).getId().equals(updatedHabit.getId())) {
                habits.set(i, updatedHabit);
                break;
            }
        }
        saveHabits(habits);
    }
    
    public void deleteHabit(String habitId) {
        List<Habit> habits = loadHabits();
        habits.removeIf(habit -> habit.getId().equals(habitId));
        saveHabits(habits);
    }
}
*/
#endif